# Consultation report – draft

Generated from the transcript; review before use in a clinical record. Not documented does not mean denied.

## History

- The patient has had loose, watery diarrhea six to seven times per day for the last three days, with associated left lower abdominal cramp-like pain that comes and goes. [F0001]
- The patient reports vomiting at the onset of symptoms but has stopped vomiting, with no blood in the vomit. [F0002]
- The patient notes feeling weak and shaky, with a sensation of heat three to four days ago, but denies current fever. [F0003]
- The patient reports loss of appetite and has been consuming mainly fluids, soups, and smoothies, which they can hold down. [F0004]
- The patient ate takeaway food from a Chinese restaurant four days ago, which they suspect may have triggered the symptoms. [F0005]
- The patient has a history of asthma, uses an inhaler, and reports it is well controlled with no other chronic gastrointestinal conditions. [F0007]
- The patient does not smoke and does not consume alcohol. [F0008]

## Background, medication and allergies

Not documented in the transcript.

## Findings

Not documented in the transcript.

## Recorded assessment

- The clinician believes the presentation is most consistent with gastroenteritis, possibly viral or bacterial, likely related to the recent takeaway meal. [F0009]

## Recorded plan and follow-up

- The clinician advises conservative management: hydration with fluids and oral rehydration solutions, rest from work for two to three days, and use of paracetamol for fever or discomfort if needed. [F0010]
- The clinician advises returning for review if symptoms do not improve within three to four days, and mentions possible further testing (e.g., stool sample) if needed. [F0011]

## Evidence

Character offsets refer to transcript.txt (zero-based, end exclusive).

- [F0001] 474–520: “um and like some pain in my like lower stomach”
- [F0001] 409–473: “it's like loose and watery stool going to the toilet quite often”
- [F0001] 618–639, 640–661: “six seven times a day”
- [F0001] 1085–1135: “it feels um like uh cramp uh like a muscular cramp”
- [F0001] 1348–1370: “just mainly my stomach”
- [F0001] 1259–1276: “it comes and goes”
- [F0002] 1949–2034: “I vomited at the start of the symptoms but now um I've stopped vomiting stop vomiting”
- [F0002] 2044–2233: “was your vomit I know it's not nice thing to talk about but was it just normal food colour yeah yeah just normal vomit yeah and there was no blood in your vomit is that right no blood no no”
- [F0003] 1585–1708: “I just mainly feel weaker I haven't had a fever um at the moment but I did notice um a temperature when the symptom started”
- [F0003] 1551–1610: “yeah it doesn't feel like uh yeah I just mainly feel weaker”
- [F0004] 2386–2488: “I had a loss of appetite um so I haven't been eating as much um but I've been able to hold down fluids”
- [F0004] 2575–2653: “just soups and uh yeah light foods like smoothies and yeah liquid foods mainly”
- [F0005] 2908–3018: “I had takeaway about four days ago um uh but other than that I've yeah been uh eating normally I think unusual”
- [F0005] 3057–3104: “yeah I ate at a Chinese restaurant with friends”
- [F0007] 3417–3491: “I mean other than um asthma um I use an inhaler everything uh else is fine”
- [F0007] 3541–3612: “that's fine just yeah you send inhaler and uh that's under control fine”
- [F0008] 4533–4572: “do you smoke at all uh no I don't smoke”
- [F0008] 4577–4644: “do you drink much in the web alcohol no I I don't drink alcohol no”
- [F0009] 5130–5187: “I wonder whether that might be the cause of your problems”
- [F0009] 5196–5434: “it seems like you may have something uh called gastroenteritis which essentially just uh tummy bug or infection of your of your tummy mainly caused by viruses but it can be uh possibility of bacteria uh causing your symptoms at this stage”
- [F0010] 5577–5609: “making sure you're well hydrated”
- [F0010] 5613–5765: “drinking fluids um there are things like dire light you can get from the pharmacy which uh it's um it helps replenish some of your minerals and vitamins”
- [F0010] 5862–6020: “first couple of days yeah if you are feeling feverish and weak taking some paracetamol two tablets up to four times a day for the first few days can also help”
- [F0010] 6021–6215: “I would certainly advise you to take some time work actually I know you're quite keen to work but um I would say next two two to three days um clears from your system take some time off and rest”
- [F0011] 6228–6527: “if your symptoms haven't got better you know in in three to four days I'd like to come back and see you again because if it is ongoing then we have to wonder whether there's something else causing symptoms and we may need to do further tests like um taking a sample of your store so we can test that”
