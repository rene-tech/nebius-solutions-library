# Arztbrief – Gesprächsentwurf

Aus dem Transkript erstellt; vor Übernahme fachlich prüfen. Nicht dokumentiert bedeutet nicht verneint.

## Anamnese

- Der Patient Jens Mager berichtet seit etwa sechs Wochen über Herzrasen, das plötzlich in Ruhe auftritt, mit einer Frequenz von bis zu 160 Schlägen pro Minute. [F0001]
- Das Herzrasen wird beschrieben als heftiges Pochen, als müsse das Herz gegen einen Widerstand arbeiten, begleitet von Zittern des gesamten Brustkorbs. [F0002]
- Die Beschwerden treten auch abends beim Einschlafen auf und sind nicht durch körperliche Anstrengung ausgelöst. [F0003]
- Der Patient beschreibt eine allgemeine innere Unruhe, die seit etwa sechs Wochen besteht. [F0004]
- Der Patient bemerkt eine emotionale Veränderung, beschreibt sich als 'seltsam unterwegs', häufig gereizt und mit geringer Stressresistenz. [F0005]
- Die aktuelle emotionale Veränderung fühlt sich anders an als eine depressive Episode vor mehreren Jahren, die seither nicht wieder aufgetreten ist. [F0006]
- Der Patient hat familiäre Vorgeschichte: Sein Großvater hatte drei Herzinfarkte und verstarb am dritten. [F0007]
- Der Patient macht sich Sorgen um eine mögliche erbliche Belastung bezüglich Herzerkrankungen. [F0008]
- Der Patient leidet unter Schlafstörungen und schläft seit Wochen selten mehr als fünf Stunden am Stück. [F0009]
- Es besteht nächtliches Schwitzen, sodass das T-Shirt morgens ausgewrungen werden könnte. [F0010]
- Der Appetit ist gut, mit erhöhtem Hungergefühl. [F0011]
- Trotz gutem Appetit hat der Patient in den letzten sechs Wochen vier Kilogramm abgenommen. [F0012]
- Der Patient studiert Maschinenbau und befindet sich in der Prüfungsphase, was mit erhöhtem Arbeitsaufwand verbunden ist. [F0013]
- Der Patient verdient zusätzlich durch Tätigkeiten wie Autowerkstatt oder Fahrradreparatur, die er als entspannend empfindet. [F0014]
- Die Beziehung zum Partner ist stabil und zufriedenstellend, auch in Bezug auf Sexualität. [F0015]

## Vorgeschichte, Medikation und Allergien

- Der Patient hatte vor mehreren Jahren eine depressive Episode infolge einer Trennung, die behandelt wurde und seither nicht wieder aufgetreten ist. [F0016]

## Befunde

- Der Arzt vermutet anhand der Symptome eine Schilddrüsenüberfunktion. [F0017]

## Dokumentierte Beurteilung

- Die Symptome des Patienten – Herzrasen, Gewichtsabnahme bei gutem Appetit, Schlafstörungen, nächtliches Schwitzen, innere Unruhe und emotionale Veränderung – sprechen für eine mögliche Schilddrüsenüberfunktion. [F0018]

## Dokumentiertes Vorgehen

- Es wird eine körperliche Untersuchung, insbesondere der Herzfunktion, geplant. [F0019]
- Es wird Blut abgenommen, um die Schilddrüsenfunktion zu überprüfen. [F0020]
- Der Patient soll bis zum nächsten Termin in zwei bis drei Tagen beobachten, ob ihm weitere Beschwerden oder Auffälligkeiten einfallen. [F0021]
- Die Laborergebnisse sollen in zwei bis drei Tagen besprochen werden. [F0022]

## Quellen

Zeichenpositionen beziehen sich auf transcript.txt (0-basiert, Ende exklusiv).

- [F0001] 0–353: “Sie arbeiten als Vertretung des Hausarztes in der Praxis von Doktor Berg. Der Patient Jens Mager stellt sich heute mit Herzbeschwerden bei Ihnen vor. Vor der körperlichen Untersuchung möchten Sie mit ihm eingespräch führen. Was führt Sie her? Ich habe seit einer Weile immer Herzrasen und zwar total heftig, also das pumpt wie verrückt und und und ein”
- [F0001] 353–709: “ganzer Brustkorb zittert, das fühlt sich auch nicht so gut an, als müsste das irgendwie gegen ein Widerstand irgendwie kämpfen und und jetzt nicht wenn ich gerannt bin oder so. Ich sitze auf dem Sofa und plötzlich gebe das los, also so bisschen bringt unangenehm in der Tat, also in Ruhe pocht ihr Herz wie gegen einen Widerstand und und heftig sehr sehr”
- [F0001] 709–1067: “schnell. Ja, haben Sie mal gemessen. Ja hundertsechzig Schläge pro Minute. Seit wann sagen Sie sechs Wochen vielleicht, ich kann es nicht genau sagen, aber so seit einer Weile fällt mir das auf, also auch abends, wenn ich verso einzuschlafen oder so plötzlich nehme ich das richtig wahr, dass auch sonst eine gewisse Unruhe in ihnen steckt. Es kann sein,”
- [F0002] 353–709: “ganzer Brustkorb zittert, das fühlt sich auch nicht so gut an, als müsste das irgendwie gegen ein Widerstand irgendwie kämpfen und und jetzt nicht wenn ich gerannt bin oder so. Ich sitze auf dem Sofa und plötzlich gebe das los, also so bisschen bringt unangenehm in der Tat, also in Ruhe pocht ihr Herz wie gegen einen Widerstand und und heftig sehr sehr”
- [F0003] 709–1067: “schnell. Ja, haben Sie mal gemessen. Ja hundertsechzig Schläge pro Minute. Seit wann sagen Sie sechs Wochen vielleicht, ich kann es nicht genau sagen, aber so seit einer Weile fällt mir das auf, also auch abends, wenn ich verso einzuschlafen oder so plötzlich nehme ich das richtig wahr, dass auch sonst eine gewisse Unruhe in ihnen steckt. Es kann sein,”
- [F0004] 709–1067: “schnell. Ja, haben Sie mal gemessen. Ja hundertsechzig Schläge pro Minute. Seit wann sagen Sie sechs Wochen vielleicht, ich kann es nicht genau sagen, aber so seit einer Weile fällt mir das auf, also auch abends, wenn ich verso einzuschlafen oder so plötzlich nehme ich das richtig wahr, dass auch sonst eine gewisse Unruhe in ihnen steckt. Es kann sein,”
- [F0004] 1785–2142: “Seltsam unterwegs heißt dünn häufig gereizt, also ganz ganz wenig Kapazität für irgendwie Stress oder so emotional so ein bisschen von der Rolle damals hat sich irgendwas verändert vor sechs Wochen, was sie nicht so richtig benennen können und was sich auch anders anfühlt als die Depression vor einigen Jahren und sie haben sich Sorge um ihr Herz gemacht,”
- [F0005] 1426–1785: “ich hatte auch mal eine depressive Episode vor ein paar Jahren, da hat ne aber war Trennung und alles Mögliche so und und das hatten ganz konkreten Grund und es wurde behandelt und es ging auch wieder weg und seitdem gab es das nie, aber ich habe mich gewundert eben oder habe mich das gefragt, weil ich auch emotional irgendwie seltsam unterwegs bin gerade.”
- [F0005] 1785–2142: “Seltsam unterwegs heißt dünn häufig gereizt, also ganz ganz wenig Kapazität für irgendwie Stress oder so emotional so ein bisschen von der Rolle damals hat sich irgendwas verändert vor sechs Wochen, was sie nicht so richtig benennen können und was sich auch anders anfühlt als die Depression vor einigen Jahren und sie haben sich Sorge um ihr Herz gemacht,”
- [F0006] 1426–1785: “ich hatte auch mal eine depressive Episode vor ein paar Jahren, da hat ne aber war Trennung und alles Mögliche so und und das hatten ganz konkreten Grund und es wurde behandelt und es ging auch wieder weg und seitdem gab es das nie, aber ich habe mich gewundert eben oder habe mich das gefragt, weil ich auch emotional irgendwie seltsam unterwegs bin gerade.”
- [F0006] 1785–2142: “Seltsam unterwegs heißt dünn häufig gereizt, also ganz ganz wenig Kapazität für irgendwie Stress oder so emotional so ein bisschen von der Rolle damals hat sich irgendwas verändert vor sechs Wochen, was sie nicht so richtig benennen können und was sich auch anders anfühlt als die Depression vor einigen Jahren und sie haben sich Sorge um ihr Herz gemacht,”
- [F0007] 1067–1426: “es ist mir, ich habe ja irgendwie schon ersi oder ist das auch neu das ist eher neu, auch eher neu. Eher, ich glaube schon hatten Sie nie Idee, was dahinter stecken könnte. Ich weiß nicht einmal mein Opa hatte drei Herzinfarkte und und wo ich mich natürlich fragte, ob das irgendwie erblich sein kann oder so und erst am dritten leider auch verstorben dann”
- [F0008] 1067–1426: “es ist mir, ich habe ja irgendwie schon ersi oder ist das auch neu das ist eher neu, auch eher neu. Eher, ich glaube schon hatten Sie nie Idee, was dahinter stecken könnte. Ich weiß nicht einmal mein Opa hatte drei Herzinfarkte und und wo ich mich natürlich fragte, ob das irgendwie erblich sein kann oder so und erst am dritten leider auch verstorben dann”
- [F0009] 2142–2498: “sonst irgendwelche Ideen. Okay, also um ihr Herz sollten wir uns kümmern und möglichst eine Erklärung finden, wie es mit Ihrem Schlaf schlecht. Ich weiß nicht, wann ich es letzte Mal mehr als fünf Stunden ein Stück geschlafen habe und ich schwitze auch absurd viel nachts. Ich kann mein T Shirt morgens ausbringen, damit die Wohnung putzen, wie ist der”
- [F0010] 2142–2498: “sonst irgendwelche Ideen. Okay, also um ihr Herz sollten wir uns kümmern und möglichst eine Erklärung finden, wie es mit Ihrem Schlaf schlecht. Ich weiß nicht, wann ich es letzte Mal mehr als fünf Stunden ein Stück geschlafen habe und ich schwitze auch absurd viel nachts. Ich kann mein T Shirt morgens ausbringen, damit die Wohnung putzen, wie ist der”
- [F0011] 2498–2845: “Appetit? Gut, gut, ich hab ich habe viel Hunger und das Gewicht. Es sind vier Kilo weg in den letzten sechs Wochen, obwohl sie viel Appetit und vier Kilo sind für mich eine ganze Menge ehrlich gesagt. Ja vielleicht erzählen Sie mir noch zwei, drei Dinge aus Ihrem sonstigen Leben, wenn Sie mögen. Was machen Sie genau beruflich? Ich studiere”
- [F0012] 2498–2845: “Appetit? Gut, gut, ich hab ich habe viel Hunger und das Gewicht. Es sind vier Kilo weg in den letzten sechs Wochen, obwohl sie viel Appetit und vier Kilo sind für mich eine ganze Menge ehrlich gesagt. Ja vielleicht erzählen Sie mir noch zwei, drei Dinge aus Ihrem sonstigen Leben, wenn Sie mögen. Was machen Sie genau beruflich? Ich studiere”
- [F0013] 2845–3202: “Maschinenbau, ich habe gerade Prüfungsphase, muss ich ein bisschen mehr machen als sonst, aber es ist nicht hier wirklich dranmatisch verdiene mir ein bisschen was neben mir dazu, bisschen Autoschrauben oder Fahrräder oder so, was was mich eher entspannt als stresst mit meiner Freundin läuft alles prima, also eigentlich alles super Sexualität alles gut.”
- [F0014] 2845–3202: “Maschinenbau, ich habe gerade Prüfungsphase, muss ich ein bisschen mehr machen als sonst, aber es ist nicht hier wirklich dranmatisch verdiene mir ein bisschen was neben mir dazu, bisschen Autoschrauben oder Fahrräder oder so, was was mich eher entspannt als stresst mit meiner Freundin läuft alles prima, also eigentlich alles super Sexualität alles gut.”
- [F0015] 2845–3202: “Maschinenbau, ich habe gerade Prüfungsphase, muss ich ein bisschen mehr machen als sonst, aber es ist nicht hier wirklich dranmatisch verdiene mir ein bisschen was neben mir dazu, bisschen Autoschrauben oder Fahrräder oder so, was was mich eher entspannt als stresst mit meiner Freundin läuft alles prima, also eigentlich alles super Sexualität alles gut.”
- [F0016] 1426–1785: “ich hatte auch mal eine depressive Episode vor ein paar Jahren, da hat ne aber war Trennung und alles Mögliche so und und das hatten ganz konkreten Grund und es wurde behandelt und es ging auch wieder weg und seitdem gab es das nie, aber ich habe mich gewundert eben oder habe mich das gefragt, weil ich auch emotional irgendwie seltsam unterwegs bin gerade.”
- [F0017] 3915–4268: “so dass ich Ihnen jetzt vorschlagen möchte, dass wir eine sorgfältige körperliche Untersuchung machen, das machen wir gleich hinten im Nachbarzimmer und dabei insbesondere auf ihr Herz schauen. Die Beschwerden, die sich schildern, lassen mich eine Schilddrüsenüberfunktion denken, deswegen würde ich Ihnen gerne Blut abnehmen, um zu klären, ob mit der”
- [F0018] 3202–3557: “Okay, ich höre raus vor sechs Wochen fangen plötzlich diese Beschwerden an Herzklopfen viel Appetit trotzdem Gewichtsabnahme, Schlafstörung, nächtliches, vor allen Dingen nächtliches Schwitzen, eine große Unruhe, die auf mit einer Wesensveränderung irgendwie einhergeht, ohne dass sie so wirklich eine Erklärung finden in ihrem Leben, wo alles sonst ganz”
- [F0018] 3915–4268: “so dass ich Ihnen jetzt vorschlagen möchte, dass wir eine sorgfältige körperliche Untersuchung machen, das machen wir gleich hinten im Nachbarzimmer und dabei insbesondere auf ihr Herz schauen. Die Beschwerden, die sich schildern, lassen mich eine Schilddrüsenüberfunktion denken, deswegen würde ich Ihnen gerne Blut abnehmen, um zu klären, ob mit der”
- [F0019] 3915–4268: “so dass ich Ihnen jetzt vorschlagen möchte, dass wir eine sorgfältige körperliche Untersuchung machen, das machen wir gleich hinten im Nachbarzimmer und dabei insbesondere auf ihr Herz schauen. Die Beschwerden, die sich schildern, lassen mich eine Schilddrüsenüberfunktion denken, deswegen würde ich Ihnen gerne Blut abnehmen, um zu klären, ob mit der”
- [F0019] 4624–4731: “Untersuchung sehen. Wenn Sie damit einverstanden, das klingt nach einem Plan. Ja schön, dann bis gleich.”
- [F0020] 3915–4268: “so dass ich Ihnen jetzt vorschlagen möchte, dass wir eine sorgfältige körperliche Untersuchung machen, das machen wir gleich hinten im Nachbarzimmer und dabei insbesondere auf ihr Herz schauen. Die Beschwerden, die sich schildern, lassen mich eine Schilddrüsenüberfunktion denken, deswegen würde ich Ihnen gerne Blut abnehmen, um zu klären, ob mit der”
- [F0020] 4268–4624: “Schilddröse alles in Ordnung ist, wenn das so wäre, könnte man das gut behandeln, bis wir uns das nächste Mal sehen in einigen Tagen können Sie ja nochmal ein bisschen schauen, ob Ihnen sonst noch was einfällt, und dann würden wir in zwei, drei Tagen uns nochmal wiedersehen und die Laborwerte besprechen und jetzt aber zuerst uns nebenan nochmal für eine”
- [F0021] 4268–4624: “Schilddröse alles in Ordnung ist, wenn das so wäre, könnte man das gut behandeln, bis wir uns das nächste Mal sehen in einigen Tagen können Sie ja nochmal ein bisschen schauen, ob Ihnen sonst noch was einfällt, und dann würden wir in zwei, drei Tagen uns nochmal wiedersehen und die Laborwerte besprechen und jetzt aber zuerst uns nebenan nochmal für eine”
- [F0022] 4268–4624: “Schilddröse alles in Ordnung ist, wenn das so wäre, könnte man das gut behandeln, bis wir uns das nächste Mal sehen in einigen Tagen können Sie ja nochmal ein bisschen schauen, ob Ihnen sonst noch was einfällt, und dann würden wir in zwei, drei Tagen uns nochmal wiedersehen und die Laborwerte besprechen und jetzt aber zuerst uns nebenan nochmal für eine”
