# Arztbrief – Gesprächsentwurf

Aus dem Transkript erstellt; vor Übernahme fachlich prüfen. Nicht dokumentiert bedeutet nicht verneint.

## Anamnese

- Das Herzrasen tritt auch beim Sitzen auf dem Sofa plötzlich auf. [F0002]
- Der Patient hat eine Herzfrequenz von 160 Schlägen pro Minute gemessen. [F0003]
- Der Patient hat vor sechs Wochen eine Veränderung bemerkt, die er nicht benennen kann. [F0006]
- Der Patient hat familiäre Vorerkrankung: Sein Großvater hatte drei Herzinfarkte und ist am dritten verstorben. [F0007]
- Der Patient hatte vor einigen Jahren eine depressive Episode, die behandelt wurde und seither nicht wieder aufgetreten ist. [F0008]
- Der Patient leidet unter Schlafstörungen und schläft seit längerem nicht mehr als fünf Stunden am Stück. [F0009]

## Vorgeschichte, Medikation und Allergien

- Der Patient studiert Maschinenbau und befindet sich in der Prüfungsphase. [F0013]
- Der Patient verdient nebenbei Geld durch Autowerkstatt- oder Fahrradreparaturen. [F0014]
- Die Nebentätigkeit empfindet der Patient als entspannend. [F0015]
- Die Beziehung des Patienten zur Freundin läuft gut. [F0016]
- Die Sexualität des Patienten ist aktuell unproblematisch. [F0017]

## Befunde

- Der Patient beschreibt eine Wesensveränderung mit Unruhe, die nicht durch aktuelle Lebensumstände erklärt werden kann. [F0018]

## Dokumentierte Beurteilung

- Die Beschwerden des Patienten lassen an eine Schilddrüsenüberfunktion denken. [F0019]

## Dokumentiertes Vorgehen

- Es wird eine körperliche Untersuchung, insbesondere der Herzfunktion, geplant. [F0020]
- Der Patient soll bis zum nächsten Termin überlegen, ob ihm weitere Beschwerden oder Veränderungen einfallen. [F0022]
- Der Patient wird in zwei bis drei Tagen erneut vorgesehen, um die Laborwerte zu besprechen. [F0023]

## Quellen

Zeichenpositionen beziehen sich auf transcript.txt (0-basiert, Ende exklusiv).

- [F0002] 532–581: “Ich sitze auf dem Sofa und plötzlich gebe das los”
- [F0003] 749–785: “Ja hundertsechzig Schläge pro Minute”
- [F0006] 1938–2025: “hat sich irgendwas verändert vor sechs Wochen, was sie nicht so richtig benennen können”
- [F0007] 1243–1421: “Ich weiß nicht einmal mein Opa hatte drei Herzinfarkte und und wo ich mich natürlich fragte, ob das irgendwie erblich sein kann oder so und erst am dritten leider auch verstorben”
- [F0008] 1427–1658: “ich hatte auch mal eine depressive Episode vor ein paar Jahren, da hat ne aber war Trennung und alles Mögliche so und und das hatten ganz konkreten Grund und es wurde behandelt und es ging auch wieder weg und seitdem gab es das nie”
- [F0009] 2289–2375: “Ich weiß nicht, wann ich es letzte Mal mehr als fünf Stunden ein Stück geschlafen habe”
- [F0013] 2833–2934: “Ich studiere Maschinenbau, ich habe gerade Prüfungsphase, muss ich ein bisschen mehr machen als sonst”
- [F0014] 2980–3071: “verdiene mir ein bisschen was neben mir dazu, bisschen Autoschrauben oder Fahrräder oder so”
- [F0015] 3077–3112: “was mich eher entspannt als stresst”
- [F0016] 3113–3179: “mit meiner Freundin läuft alles prima, also eigentlich alles super”
- [F0017] 3180–3200: “Sexualität alles gut”
- [F0018] 3397–3568: “eine große Unruhe, die auf mit einer Wesensveränderung irgendwie einhergeht, ohne dass sie so wirklich eine Erklärung finden in ihrem Leben, wo alles sonst ganz rund läuft”
- [F0019] 4111–4196: “Die Beschwerden, die sich schildern, lassen mich eine Schilddrüsenüberfunktion denken”
- [F0020] 3960–4108: “dass wir eine sorgfältige körperliche Untersuchung machen, das machen wir gleich hinten im Nachbarzimmer und dabei insbesondere auf ihr Herz schauen”
- [F0022] 4351–4478: “bis wir uns das nächste Mal sehen in einigen Tagen können Sie ja nochmal ein bisschen schauen, ob Ihnen sonst noch was einfällt”
- [F0023] 4484–4573: “dann würden wir in zwei, drei Tagen uns nochmal wiedersehen und die Laborwerte besprechen”
