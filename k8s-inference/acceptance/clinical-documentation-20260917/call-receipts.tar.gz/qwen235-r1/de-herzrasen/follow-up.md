# Offene Punkte und mögliche Rückfragen

Nicht Teil des Arztbriefs. Vorschläge, keine vollständige klinische Checkliste. Nicht im Transkript gefunden heißt nicht, dass die Frage nicht gestellt wurde.

- Wann genau trat das Herzrasen erstmals auf und wie lange dauern die Episoden typischerweise an? — Obwohl das plötzliche Auftreten des Herzrasens beschrieben ist (F0002), fehlt eine klare Angabe zum Erstauftreten und zur Dauer der Episoden, was für die Differenzialdiagnose wichtig ist. (F0002; not_documented)
- Wurde die Herzfrequenz von 160 Schlägen pro Minute während einer Episode gemessen und mit welchem Gerät? — Die gemessene Frequenz wird genannt (F0003), aber es ist unklar, ob dies während einer typischen Episode erfolgte und ob die Messung zuverlässig ist (z. B. Pulsmessgerät, Smartphone, manuelle Messung). (F0003; unclear_source)
- Welche Art von Veränderung vor sechs Wochen meint der Patient, obwohl er sie nicht benennen kann? — Es wird eine nicht näher definierte Veränderung vor sechs Wochen erwähnt (F0006), die möglicherweise mit dem Beginn der Symptome korreliert – eine Präzisierung könnte Hinweise auf Auslöser liefern. (F0006; not_documented)
- Gibt es aktuelle oder frühere Medikamente, Nahrungsergänzungsmittel oder Substanzeinsatz, die eine Schilddrüsenüberfunktion oder Herzrasen auslösen könnten? — Obwohl eine Schilddrüsenüberfunktion vermutet wird (F0019), sind potenzielle medikamentöse oder substanzbezogene Ursachen nicht dokumentiert. (F0019; not_documented)
- Bestehen weitere vegetative Symptome wie Gewichtsverlust, Schwitzen oder Tremor, die auf eine Schilddrüsenüberfunktion hindeuten könnten? — Die Verdachtsdiagnose Schilddrüsenüberfunktion (F0019) wäre durch weitere typische Symptome unterstützbar, die jedoch nicht erwähnt werden. (F0019; not_documented)

7 Kandidaten nicht übernommen; siehe review.json. Vollständigkeit prüfen.
