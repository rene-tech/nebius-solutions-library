# Arztbrief – Gesprächsentwurf

Aus dem Transkript erstellt; vor Übernahme fachlich prüfen. Nicht dokumentiert bedeutet nicht verneint.

## Anamnese

- Patient reports persistent, severe heart palpitations described as "pumpt wie verrückt" and "gegen einen Widerstand" occurring at rest, lasting several weeks, with onset approximately six weeks ago, accompanied by night sweats, insomnia (sleeping less than five hours), and unintentional weight loss of four kilograms despite preserved appetite. [F0001]
- Patient denies recent physical exertion as trigger and reports episodes occurring while seated, with associated chest tremor and perceived cardiac struggle. [F0002]
- Patient reports a family history of three myocardial infarctions and early death in grandfather, raising concern for hereditary cardiac predisposition. [F0003]
- Patient reports a past depressive episode several years ago with clear psychosocial trigger and successful treatment, but denies current depressive symptoms; however, notes recent emotional lability, irritability, and reduced stress tolerance occurring approximately six weeks ago, which he perceives as distinct from prior depression. [F0004]
- Patient reports additional symptoms including excessive night sweating, difficulty falling asleep, and heightened autonomic arousal (e.g., "Unruhe in ihnen steckt"), which he associates with recent life changes but cannot precisely identify. [F0005]
- Patient denies current medication use, substance abuse, or other systemic symptoms beyond those described; reports normal appetite despite weight loss and denies gastrointestinal or metabolic complaints. [F0006]

## Vorgeschichte, Medikation und Allergien

Nicht im Transkript dokumentiert.

## Befunde

Nicht im Transkript dokumentiert.

## Dokumentierte Beurteilung

- Clinician considers possible hyperthyroidism (Schilddrüsenüberfunktion) as a potential explanation for the constellation of palpitations, weight loss, insomnia, and night sweats, and plans diagnostic evaluation accordingly. [F0007]

## Dokumentiertes Vorgehen

- Clinician proposes immediate physical examination focusing on cardiovascular system and orders laboratory testing, specifically thyroid function studies, to evaluate for hyperthyroidism, with follow-up appointment scheduled in two to three days to discuss results. [F0008]

## Quellen

Zeichenpositionen beziehen sich auf transcript.txt (0-basiert, Ende exklusiv).

- [F0001] 0–353: “Sie arbeiten als Vertretung des Hausarztes in der Praxis von Doktor Berg. Der Patient Jens Mager stellt sich heute mit Herzbeschwerden bei Ihnen vor. Vor der körperlichen Untersuchung möchten Sie mit ihm eingespräch führen. Was führt Sie her? Ich habe seit einer Weile immer Herzrasen und zwar total heftig, also das pumpt wie verrückt und und und ein”
- [F0001] 353–709: “ganzer Brustkorb zittert, das fühlt sich auch nicht so gut an, als müsste das irgendwie gegen ein Widerstand irgendwie kämpfen und und jetzt nicht wenn ich gerannt bin oder so. Ich sitze auf dem Sofa und plötzlich gebe das los, also so bisschen bringt unangenehm in der Tat, also in Ruhe pocht ihr Herz wie gegen einen Widerstand und und heftig sehr sehr”
- [F0001] 709–1067: “schnell. Ja, haben Sie mal gemessen. Ja hundertsechzig Schläge pro Minute. Seit wann sagen Sie sechs Wochen vielleicht, ich kann es nicht genau sagen, aber so seit einer Weile fällt mir das auf, also auch abends, wenn ich verso einzuschlafen oder so plötzlich nehme ich das richtig wahr, dass auch sonst eine gewisse Unruhe in ihnen steckt. Es kann sein,”
- [F0001] 2498–2845: “Appetit? Gut, gut, ich hab ich habe viel Hunger und das Gewicht. Es sind vier Kilo weg in den letzten sechs Wochen, obwohl sie viel Appetit und vier Kilo sind für mich eine ganze Menge ehrlich gesagt. Ja vielleicht erzählen Sie mir noch zwei, drei Dinge aus Ihrem sonstigen Leben, wenn Sie mögen. Was machen Sie genau beruflich? Ich studiere”
- [F0001] 3202–3557: “Okay, ich höre raus vor sechs Wochen fangen plötzlich diese Beschwerden an Herzklopfen viel Appetit trotzdem Gewichtsabnahme, Schlafstörung, nächtliches, vor allen Dingen nächtliches Schwitzen, eine große Unruhe, die auf mit einer Wesensveränderung irgendwie einhergeht, ohne dass sie so wirklich eine Erklärung finden in ihrem Leben, wo alles sonst ganz”
- [F0002] 353–709: “ganzer Brustkorb zittert, das fühlt sich auch nicht so gut an, als müsste das irgendwie gegen ein Widerstand irgendwie kämpfen und und jetzt nicht wenn ich gerannt bin oder so. Ich sitze auf dem Sofa und plötzlich gebe das los, also so bisschen bringt unangenehm in der Tat, also in Ruhe pocht ihr Herz wie gegen einen Widerstand und und heftig sehr sehr”
- [F0003] 1067–1426: “es ist mir, ich habe ja irgendwie schon ersi oder ist das auch neu das ist eher neu, auch eher neu. Eher, ich glaube schon hatten Sie nie Idee, was dahinter stecken könnte. Ich weiß nicht einmal mein Opa hatte drei Herzinfarkte und und wo ich mich natürlich fragte, ob das irgendwie erblich sein kann oder so und erst am dritten leider auch verstorben dann”
- [F0004] 1426–1785: “ich hatte auch mal eine depressive Episode vor ein paar Jahren, da hat ne aber war Trennung und alles Mögliche so und und das hatten ganz konkreten Grund und es wurde behandelt und es ging auch wieder weg und seitdem gab es das nie, aber ich habe mich gewundert eben oder habe mich das gefragt, weil ich auch emotional irgendwie seltsam unterwegs bin gerade.”
- [F0004] 1785–2142: “Seltsam unterwegs heißt dünn häufig gereizt, also ganz ganz wenig Kapazität für irgendwie Stress oder so emotional so ein bisschen von der Rolle damals hat sich irgendwas verändert vor sechs Wochen, was sie nicht so richtig benennen können und was sich auch anders anfühlt als die Depression vor einigen Jahren und sie haben sich Sorge um ihr Herz gemacht,”
- [F0005] 1785–2142: “Seltsam unterwegs heißt dünn häufig gereizt, also ganz ganz wenig Kapazität für irgendwie Stress oder so emotional so ein bisschen von der Rolle damals hat sich irgendwas verändert vor sechs Wochen, was sie nicht so richtig benennen können und was sich auch anders anfühlt als die Depression vor einigen Jahren und sie haben sich Sorge um ihr Herz gemacht,”
- [F0005] 3202–3557: “Okay, ich höre raus vor sechs Wochen fangen plötzlich diese Beschwerden an Herzklopfen viel Appetit trotzdem Gewichtsabnahme, Schlafstörung, nächtliches, vor allen Dingen nächtliches Schwitzen, eine große Unruhe, die auf mit einer Wesensveränderung irgendwie einhergeht, ohne dass sie so wirklich eine Erklärung finden in ihrem Leben, wo alles sonst ganz”
- [F0006] 2498–2845: “Appetit? Gut, gut, ich hab ich habe viel Hunger und das Gewicht. Es sind vier Kilo weg in den letzten sechs Wochen, obwohl sie viel Appetit und vier Kilo sind für mich eine ganze Menge ehrlich gesagt. Ja vielleicht erzählen Sie mir noch zwei, drei Dinge aus Ihrem sonstigen Leben, wenn Sie mögen. Was machen Sie genau beruflich? Ich studiere”
- [F0006] 2845–3202: “Maschinenbau, ich habe gerade Prüfungsphase, muss ich ein bisschen mehr machen als sonst, aber es ist nicht hier wirklich dranmatisch verdiene mir ein bisschen was neben mir dazu, bisschen Autoschrauben oder Fahrräder oder so, was was mich eher entspannt als stresst mit meiner Freundin läuft alles prima, also eigentlich alles super Sexualität alles gut.”
- [F0007] 3915–4268: “so dass ich Ihnen jetzt vorschlagen möchte, dass wir eine sorgfältige körperliche Untersuchung machen, das machen wir gleich hinten im Nachbarzimmer und dabei insbesondere auf ihr Herz schauen. Die Beschwerden, die sich schildern, lassen mich eine Schilddrüsenüberfunktion denken, deswegen würde ich Ihnen gerne Blut abnehmen, um zu klären, ob mit der”
- [F0008] 3915–4268: “so dass ich Ihnen jetzt vorschlagen möchte, dass wir eine sorgfältige körperliche Untersuchung machen, das machen wir gleich hinten im Nachbarzimmer und dabei insbesondere auf ihr Herz schauen. Die Beschwerden, die sich schildern, lassen mich eine Schilddrüsenüberfunktion denken, deswegen würde ich Ihnen gerne Blut abnehmen, um zu klären, ob mit der”
- [F0008] 4268–4624: “Schilddröse alles in Ordnung ist, wenn das so wäre, könnte man das gut behandeln, bis wir uns das nächste Mal sehen in einigen Tagen können Sie ja nochmal ein bisschen schauen, ob Ihnen sonst noch was einfällt, und dann würden wir in zwei, drei Tagen uns nochmal wiedersehen und die Laborwerte besprechen und jetzt aber zuerst uns nebenan nochmal für eine”
- [F0008] 4624–4731: “Untersuchung sehen. Wenn Sie damit einverstanden, das klingt nach einem Plan. Ja schön, dann bis gleich.”
