# Offene Punkte und mögliche Rückfragen

Nicht Teil des Arztbriefs. Vorschläge, keine vollständige klinische Checkliste. Nicht im Transkript gefunden heißt nicht, dass die Frage nicht gestellt wurde.

- Gibt es eine bekannte Schilddrüsenerkrankung in der Familie, insbesondere bei nahen Verwandten? — Da der Verdacht auf eine Schilddrüsenüberfunktion besteht, wäre eine familiäre Vorgeschichte relevant für die Beurteilung der Wahrscheinlichkeit einer autoimmunen Ursache wie Morbus Basedow. (F0017; not_documented)
- Wurde in den letzten Wochen oder Monaten eine Schilddrüsenuntersuchung (z. B. Tastbefund, Ultraschall) durchgeführt? — Ein vorheriger Befund könnte Hinweise auf eine strukturelle Veränderung der Schilddrüse liefern, der den klinischen Verdacht unterstützen oder absichern würde. (F0017; not_documented)
- Bestehen weitere vegetative Symptome wie Tremor, Hitzeintoleranz oder Durchfall, die auf eine Hyperthyreose hindeuten könnten? — Diese Symptome würden den klinischen Verdacht auf eine Schilddrüsenüberfunktion stärken und helfen, die Differenzialdiagnose einzugrenzen. (F0016; unclear_source)
- Hat der Patient Medikamente, Nahrungsergänzungsmittel oder Drogen eingenommen, die Herzrasen oder metabolische Symptome auslösen könnten? — Substanzen wie Stimulanzien, Schilddrüsenhormone oder Koffein in hoher Dosis könnten die Symptomatik erklären und müssten abgeklärt werden. (F0001, F0007, F0008; not_documented)
- Wie häufig und wie lange dauern die Episoden des Herzrasens jeweils an? — Die Dauer und Frequenz der Herzrasenepisoden sind wichtig, um zwischen paroxysmaler Tachykardie, anhaltender Arrhythmie oder funktionellen Beschwerden zu differenzieren. (F0001; unclear_source)
