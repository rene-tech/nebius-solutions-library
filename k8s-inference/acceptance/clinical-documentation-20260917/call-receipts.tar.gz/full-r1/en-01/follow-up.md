# Uncertainties and suggested questions

Not part of the report. Suggestions, not a complete clinical checklist. Not found in the transcript does not mean the doctor did not ask.

