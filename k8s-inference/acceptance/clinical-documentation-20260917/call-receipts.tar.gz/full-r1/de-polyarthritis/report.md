# Arztbrief – Gesprächsentwurf

Aus dem Transkript erstellt; vor Übernahme fachlich prüfen. Nicht dokumentiert bedeutet nicht verneint.

## Anamnese

- Die Patientin Frau Miriam Klein klagt seit mehreren Wochen über Gelenkschmerzen, Schwellungen und Morgensteifigkeit in den Fingern. [F0001]
- Die Patientin nimmt bei Schmerzen Ipophäen, was die Beschwerden verbessert. [F0004]
- Die Patientin vermutet, dass die Schmerzen durch Volleyball oder eine leichte Prellung verursacht wurden. [F0005]
- Die Großtante der Patientin hatte Rheuma. [F0006]
- Die Patientin ist Sportlehrerin und macht sich Sorgen, dass sie ihren Beruf nicht mehr ausüben kann. [F0014]

## Vorgeschichte, Medikation und Allergien

- Gestern wurde die Patientin in ihrer Hausarztpraxis untersucht und Blut wurde abgenommen. [F0002]

## Befunde

- Die Laborwerte sprechen im Kontext der Anamnese mit an Sicherheit grenzender Wahrscheinlichkeit für das Vorliegen einer chronischen Polyarthritis. [F0003]
- Der Arzt geht aktuell davon aus, dass die Patientin an Rheuma leidet, basierend auf den eindeutigen Laborwerten. [F0007]

## Dokumentierte Beurteilung

- Der Arzt schlägt vor, einen Rheumatologen hinzuzuziehen, um die weitere Behandlung abzuklären. [F0008]
- Der Verlauf der Erkrankung ist nicht vorhersagbar und muss nicht dem Verlauf bei der Großtante der Patientin entsprechen. [F0009]
- Es könnte eine erbliche Komponente bei der Erkrankung geben, da Rheuma in der Familie vorkommt, aber das bedeutet nicht, dass der Verlauf gleich ist. [F0010]
- Es ist nicht sicher vorhersagbar, ob die Patientin berufsunfähig wird. [F0015]
- Es gibt Sportlehrerinnen mit Rheuma, die bis zur Rente arbeiten können, wenn sie die Medikamente gut vertragen und keine schweren Gelenkzerstörungen auftreten. [F0016]
- Trotz Medikamenteneinnahme kann der Verlauf auch ungünstig sein. [F0017]

## Dokumentiertes Vorgehen

- Es gibt Medikamente, mit denen die Erkrankung heute häufig sehr gut kontrolliert werden kann, sodass keine Gelenkzerstörung auftritt. [F0011]
- Die Medikamente sind nicht für jeden gut verträglich und erfordern eine engmaschige Überwachung. [F0012]
- Die Patientin muss häufiger in die Praxis kommen als gewohnt. [F0013]
- Der Arzt schlägt vor, gemeinsam zu überlegen, zu welchem Rheumatologen die Patientin gehen möchte. [F0018]
- Der Arzt empfiehlt, zunächst abzuwarten, was der Rheumatologe empfiehlt, und später über Nebenwirkungen zu sprechen. [F0019]
- Der Arzt schlägt vor, sich in der nächsten Woche erneut zu treffen, um konkrete Schritte zu planen, nachdem die Diagnose etwas verarbeitet wurde. [F0020]
- Der Arzt möchte das Gespräch heute nicht überfrachten und rät, die Informationen erstmal sacken zu lassen. [F0021]
- Die Patientin darf eine Begleitperson zum nächsten Gespräch mitbringen. [F0022]
- Die Patientin soll in der nächsten Woche Kontakt aufnehmen, um einen Termin beim Rheumatologen zu vereinbaren. [F0023]

## Quellen

Zeichenpositionen beziehen sich auf transcript.txt (0-basiert, Ende exklusiv).

- [F0001] 0–354: “Die Patientin Frau Miriam Klein klagt seit mehreren Wochen über bestehende Gelenkschmerzen, Schwellungen und Morgensteifigkeit in den Fingern. Gestern wurde sie in ihrer Hausarztpraxis diesbezüglich untersucht. Auch wurde Blut abgenommen. Die Laborwerte sprechen im Kontext der Anamnese mit an Sicherheit grenzender Wahrscheinlichkeit für das Vorliegen”
- [F0002] 0–354: “Die Patientin Frau Miriam Klein klagt seit mehreren Wochen über bestehende Gelenkschmerzen, Schwellungen und Morgensteifigkeit in den Fingern. Gestern wurde sie in ihrer Hausarztpraxis diesbezüglich untersucht. Auch wurde Blut abgenommen. Die Laborwerte sprechen im Kontext der Anamnese mit an Sicherheit grenzender Wahrscheinlichkeit für das Vorliegen”
- [F0003] 0–354: “Die Patientin Frau Miriam Klein klagt seit mehreren Wochen über bestehende Gelenkschmerzen, Schwellungen und Morgensteifigkeit in den Fingern. Gestern wurde sie in ihrer Hausarztpraxis diesbezüglich untersucht. Auch wurde Blut abgenommen. Die Laborwerte sprechen im Kontext der Anamnese mit an Sicherheit grenzender Wahrscheinlichkeit für das Vorliegen”
- [F0003] 354–707: “einer chronischen Polyatritis. Heute kommt die Patientin, um über das Ergebnis der Laboruntersuchungen zu sprechen. Ihre Aufgabe ist es der Patientin die schlechte Nachricht zu übermitteln, dass sie an Gelenkräume erkrankt ist. Guten Tag von Klein, nehmen Sie auf Platz, Frau Klein, wie geht es hin? Soweit ganz gut heute Morgen war es nochmal so ein”
- [F0004] 707–1065: “bisschen, da habe ich dann Ipophäen genommen und jetzt ist besser. Diese Schmerzen, die sie seit ein paar Wochen. Genau, weswegen ich gekommen bin. Richtig. Ich glaube wir hatten uns heute für abredet, um die Ergebnisse der Blutuntersuchung zu bestehen. Genau nicht genau. Ich würde auch gerne haben Sie selber eine Idee, wo die Schmerzen hier kommen?”
- [F0005] 1065–1418: “Ich habe es gedacht, es geben vom Volleyball oder so, sondern irgendwie leichte Prellung oder irgendwie sonst nix. Ich habe tatsächlich eine nicht so gute Nachhalt für sie. Die Laborwerte, die wir abgenommen haben, sprechen dafür, dass bei Ihnen einen Rollenmar vorliegt, ein Gelenkrolmar weiß nicht, ob Sie davon schon mal was gehört haben. Ja doch”
- [F0006] 1418–1775: “schon, also meine Großtante hatte Räume. Genau, aber das ist jetzt sicher, dass die Laborwehrte sind eindeutig dafür, ich denke, dass wenn der weiteren Behandlung nochmal einen Rheumatologen hinzuziehen würden, aber ich gehe jetzt erstmal davon aus, dass das tatsächlich räume ist, was Sie haben. Geht jetzt ein bisschen plötzlich. Das habe ich jetzt gar”
- [F0007] 1418–1775: “schon, also meine Großtante hatte Räume. Genau, aber das ist jetzt sicher, dass die Laborwehrte sind eindeutig dafür, ich denke, dass wenn der weiteren Behandlung nochmal einen Rheumatologen hinzuziehen würden, aber ich gehe jetzt erstmal davon aus, dass das tatsächlich räume ist, was Sie haben. Geht jetzt ein bisschen plötzlich. Das habe ich jetzt gar”
- [F0008] 1418–1775: “schon, also meine Großtante hatte Räume. Genau, aber das ist jetzt sicher, dass die Laborwehrte sind eindeutig dafür, ich denke, dass wenn der weiteren Behandlung nochmal einen Rheumatologen hinzuziehen würden, aber ich gehe jetzt erstmal davon aus, dass das tatsächlich räume ist, was Sie haben. Geht jetzt ein bisschen plötzlich. Das habe ich jetzt gar”
- [F0009] 1775–2133: “nicht. Habe ich gar nicht so erwartet. Das nervig sie sagten, dass ihre Großtante das hatte. Ja später im Rollstuhl weiß irgendwie viel sie von Rollen wissen, ob es ihn helfen würde, wenn ich ihn dazu ein bisschen sage, das ist nicht immer bei jedem gleich. Aber trotzdem endet er dann so, oder wir sind ein bisschen zu erzählen. Das ist tatsächlich so,”
- [F0009] 2133–2491: “dass es bei verschiedenen Menschen ganz unterschiedlich laufen kann. Und das was sie bei ihrer Großtante gesehen haben, muss nicht das sein, was bei ihnen auftritt. Das ist überhaupt nicht vorhersagbar. Das ist vorstellbar, dass eine erbliche Komponente da ist, wenn das in der Familie war, aber das heißt überhaupt nicht, dass dann auch die Verläufe immer”
- [F0010] 2133–2491: “dass es bei verschiedenen Menschen ganz unterschiedlich laufen kann. Und das was sie bei ihrer Großtante gesehen haben, muss nicht das sein, was bei ihnen auftritt. Das ist überhaupt nicht vorhersagbar. Das ist vorstellbar, dass eine erbliche Komponente da ist, wenn das in der Familie war, aber das heißt überhaupt nicht, dass dann auch die Verläufe immer”
- [F0010] 2491–2850: “gleich sind. Das heißt ja dann schon, dass ich jetzt schwere Medikamente nehmen muss oder hier läuft das ab. Ja schwere Medikamente, also es gibt Medikamente, mit denen man heute die diese Erkrankung sehr gut häufig, sehr gut kontrollieren kann, so dass sie nicht fortschreitet und dass diese Gelenkserstörung gar nicht erst auftreten. Und die sind dann, da”
- [F0011] 2491–2850: “gleich sind. Das heißt ja dann schon, dass ich jetzt schwere Medikamente nehmen muss oder hier läuft das ab. Ja schwere Medikamente, also es gibt Medikamente, mit denen man heute die diese Erkrankung sehr gut häufig, sehr gut kontrollieren kann, so dass sie nicht fortschreitet und dass diese Gelenkserstörung gar nicht erst auftreten. Und die sind dann, da”
- [F0012] 2491–2850: “gleich sind. Das heißt ja dann schon, dass ich jetzt schwere Medikamente nehmen muss oder hier läuft das ab. Ja schwere Medikamente, also es gibt Medikamente, mit denen man heute die diese Erkrankung sehr gut häufig, sehr gut kontrollieren kann, so dass sie nicht fortschreitet und dass diese Gelenkserstörung gar nicht erst auftreten. Und die sind dann, da”
- [F0012] 2850–3205: “muss man, da muss man filmiert gucken, die sind nicht für jeden gut verträglich. Das bedeutet, dass sie häufiger in die Praxis kommen müssen, als sie das gewohnt sind. Auf der anderen Seite viele Patienten vertragen ja auch gut, ohne dass Nebenwirkung auftreten. Mein Beruf in Zukunft, also ich bin Sportlehrerin. Das kann ich ja dann irgendwann nicht”
- [F0013] 2850–3205: “muss man, da muss man filmiert gucken, die sind nicht für jeden gut verträglich. Das bedeutet, dass sie häufiger in die Praxis kommen müssen, als sie das gewohnt sind. Auf der anderen Seite viele Patienten vertragen ja auch gut, ohne dass Nebenwirkung auftreten. Mein Beruf in Zukunft, also ich bin Sportlehrerin. Das kann ich ja dann irgendwann nicht”
- [F0014] 2850–3205: “muss man, da muss man filmiert gucken, die sind nicht für jeden gut verträglich. Das bedeutet, dass sie häufiger in die Praxis kommen müssen, als sie das gewohnt sind. Auf der anderen Seite viele Patienten vertragen ja auch gut, ohne dass Nebenwirkung auftreten. Mein Beruf in Zukunft, also ich bin Sportlehrerin. Das kann ich ja dann irgendwann nicht”
- [F0014] 3205–3564: “mehr ausüben oder wie ist das? Kann man so nicht sagen ein Schock. Ja schon mich gerade bei mir passieren konnte. Sie fragen sich, was ihr falsch gemacht haben, wir wissen gar nicht, warum rollen aber jemanden auftritt. Wir wissen nichts, was jemand falsch machen könnte. Also ich will jetzt nicht mal sagen, Sie haben nicht falsch gemacht, weil von der”
- [F0015] 3564–3921: “Erkrankung so wenig verstanden, sie tritt auf und wir wissen nicht warum sie bei dem einen Auftritt, wenn dem anderen nicht. Und wir können eben auch nicht die schwere Vorhersagen und darum nein, das heißt nicht, dass sie berufenfähig werden, sondern es heißt, dass für sie ein Risiko besteht. Deswegen Berufen fähig zu werden. Es gibt Sportlehrerinnen,”
- [F0016] 3564–3921: “Erkrankung so wenig verstanden, sie tritt auf und wir wissen nicht warum sie bei dem einen Auftritt, wenn dem anderen nicht. Und wir können eben auch nicht die schwere Vorhersagen und darum nein, das heißt nicht, dass sie berufenfähig werden, sondern es heißt, dass für sie ein Risiko besteht. Deswegen Berufen fähig zu werden. Es gibt Sportlehrerinnen,”
- [F0016] 3921–4279: “die Räume kriegen und trotzdem ist zur Rente arbeiten können. Ihre Medikamente gut vertragen und wo es nicht so gelenkt zerstörungen kommt. Ich kann mir das nur nicht versprechen. Also trotz Medikamente kann es auch anders verlaufen, es geht in den noch durch den Kopf. Das Mögliche ist gerade so alles glaube so mein Gefühl für dieses Gespräch wäre, dass”
- [F0017] 3921–4279: “die Räume kriegen und trotzdem ist zur Rente arbeiten können. Ihre Medikamente gut vertragen und wo es nicht so gelenkt zerstörungen kommt. Ich kann mir das nur nicht versprechen. Also trotz Medikamente kann es auch anders verlaufen, es geht in den noch durch den Kopf. Das Mögliche ist gerade so alles glaube so mein Gefühl für dieses Gespräch wäre, dass”
- [F0018] 4279–4635: “war, dass man bei dieser Information belassen und ich mit Ihnen überlegen würde, zu welchem Rheumatologen Sie gerne gehen möchten und dass wir dann erstmal abwarten, was dir empfiehlt und wir dann sehr gerne auch mit mir nochmal über Nebenwirkungen sprechen können. Muss man jetzt einfach abwarten, was hielten die davon, wenn wir uns noch ein zweites Mal”
- [F0019] 4279–4635: “war, dass man bei dieser Information belassen und ich mit Ihnen überlegen würde, zu welchem Rheumatologen Sie gerne gehen möchten und dass wir dann erstmal abwarten, was dir empfiehlt und wir dann sehr gerne auch mit mir nochmal über Nebenwirkungen sprechen können. Muss man jetzt einfach abwarten, was hielten die davon, wenn wir uns noch ein zweites Mal”
- [F0020] 4279–4635: “war, dass man bei dieser Information belassen und ich mit Ihnen überlegen würde, zu welchem Rheumatologen Sie gerne gehen möchten und dass wir dann erstmal abwarten, was dir empfiehlt und wir dann sehr gerne auch mit mir nochmal über Nebenwirkungen sprechen können. Muss man jetzt einfach abwarten, was hielten die davon, wenn wir uns noch ein zweites Mal”
- [F0020] 4635–4988: “zusammensetzen und so konkrete Schritte zu planen, dass das erstmal so ein bisschen Sacken kann. Ich merke, wie unerwartet sie das getroffen hat. Sprechen können, der darf natürlich gerne mitkommen und dass wir dann so ein bisschen in die konkreten Planungen reingehen. Ich möchte das heute nicht überfrachten. Das gut kommen auch bestimmt wieder neue”
- [F0021] 4635–4988: “zusammensetzen und so konkrete Schritte zu planen, dass das erstmal so ein bisschen Sacken kann. Ich merke, wie unerwartet sie das getroffen hat. Sprechen können, der darf natürlich gerne mitkommen und dass wir dann so ein bisschen in die konkreten Planungen reingehen. Ich möchte das heute nicht überfrachten. Das gut kommen auch bestimmt wieder neue”
- [F0021] 4988–5215: “Fragen. Genau. Ja, dann gucken Sie einfach in der Woche einfach nächste Woche, wie Sie möchten, sehe zu, dass sie schnell einen Termin am Rhematologen kriegen, aber ich würde es heute erstmal gerne dabei belasten. Alles gut”
- [F0022] 4635–4988: “zusammensetzen und so konkrete Schritte zu planen, dass das erstmal so ein bisschen Sacken kann. Ich merke, wie unerwartet sie das getroffen hat. Sprechen können, der darf natürlich gerne mitkommen und dass wir dann so ein bisschen in die konkreten Planungen reingehen. Ich möchte das heute nicht überfrachten. Das gut kommen auch bestimmt wieder neue”
- [F0023] 4988–5215: “Fragen. Genau. Ja, dann gucken Sie einfach in der Woche einfach nächste Woche, wie Sie möchten, sehe zu, dass sie schnell einen Termin am Rhematologen kriegen, aber ich würde es heute erstmal gerne dabei belasten. Alles gut”
