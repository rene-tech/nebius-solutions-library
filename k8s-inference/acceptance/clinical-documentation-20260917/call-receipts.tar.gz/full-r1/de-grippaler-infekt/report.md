# Arztbrief – Gesprächsentwurf

Aus dem Transkript erstellt; vor Übernahme fachlich prüfen. Nicht dokumentiert bedeutet nicht verneint.

## Anamnese

- Der Patient leidet seit drei Monaten an Symptomen eines grippalen Infekts. [F0001]
- Die Symptome begannen während einer Besprechung, in der die Klimaanlage stark lief und der Patient mit einem T-Shirt unterkühlt war. [F0002]
- Der Patient nimmt gelegentlich Ibuprofen zur Schmerzlinderung. [F0004]
- Der Patient möchte Ibuprofen nicht übermäßig einnehmen, da er weiß, dass es den Körper belastet. [F0005]
- Der Patient arbeitet derzeit an einem Projekt an der Freien Universität Berlin im Bereich Forschung. [F0006]
- Der Patient macht derzeit kaum Pausen und hat keine Zeit für Erholung. [F0011]
- Der Patient hofft auf ein Medikament, das entweder den Infekt beseitigt oder die Symptome stärker lindert. [F0012]
- Der Patient erwägt die Gabe eines Antibiotikums, um die Beschwerden zu beenden. [F0013]
- Der Patient sieht eine Krankschreibung als nicht machbar an, da er Zeitmangel und Leistungsdruck empfindet. [F0021]
- Der Patient befürchtet, dass eine Krankschreibung negativ auf seine Chancen für einen weiteren Vertrag wirken könnte. [F0022]
- Der Patient gibt an, dass andere Kollegen trotz Erkältung weiterarbeiten und er sich daher nicht krankmelden möchte. [F0023]
- Der Patient fühlt sich in einer Zwickmühle, da er sich weder krankmelden noch weiter unter Druck arbeiten möchte. [F0029]
- Der Patient würde einem Freund raten, sich bei einer solchen Erkältung krankzuschreiben. [F0030]
- Der Patient glaubt, dass seine Freundin seine aktuelle Situation nicht besonders gut findet, thematisiert es aber nicht offen. [F0031]

## Vorgeschichte, Medikation und Allergien

- Das Projekt hat eine Laufzeit von sechs Monaten, der Patient ist derzeit zur Hälfte durch. [F0007]
- Der Arbeitsvertrag des Patienten ist an die Projektlaufzeit gebunden. [F0008]
- Nach Abschluss des Projekts hofft der Patient auf einen weiteren Vertrag. [F0009]
- Der Patient arbeitet derzeit zehn bis elf Stunden pro Tag und sichtet oft auch abends Unterlagen. [F0010]
- Der Patient lebt aktuell allein, seine Freundin wohnt nicht in der Nähe. [F0014]
- Der Patient besucht seine Freundin an einigen Wochenenden. [F0015]
- Der Patient hat derzeit keine Energie und Gelegenheit für Hobbys oder Sport. [F0016]

## Befunde

- Der Patient beschreibt anhaltende Kopfschmerzen und verstopfte Nasennebenhöhlen. [F0003]

## Dokumentierte Beurteilung

- Die Symptome des Patienten entsprechen einem langanhaltenden viralen Infekt. [F0017]
- Antibiotika würden bei einem viralen Infekt mehr schaden als nützen. [F0018]
- Die entscheidende Maßnahme zur Genesung wäre ausreichende Ruhe und Schonung. [F0019]
- Die Ärztin nimmt bei dem Patienten einen hohen Stress- und Leistungsdruck wahr. [F0024]
- Die Ärztin vermutet, dass der anhaltende Infekt mit dem hohen Stresslevel des Patienten zusammenhängt. [F0025]
- Der Patient empfindet neben körperlichen Beschwerden auch Hilflosigkeit. [F0032]

## Dokumentiertes Vorgehen

- Die Ärztin schlägt vor, den Patienten für zwei bis drei Tage krankzuschreiben, um Erholung zu ermöglichen. [F0020]
- Die Ärztin schlägt vor, mit einer Krankschreibung von wenigen Tagen zu beginnen, um den Druck zu reduzieren. [F0026]
- Die Ärztin schlägt vor, das Wochenende mit einzubeziehen, sodass der Patient insgesamt etwa fünf Tage zur Erholung hätte. [F0027]
- Die Ärztin plant, den Patienten nach dem Gespräch körperlich zu untersuchen. [F0028]
- Die Ärztin ermutigt den Patienten, die Möglichkeit der Krankschreibung zu überdenken und zu prüfen, was machbar wäre. [F0033]

## Quellen

Zeichenpositionen beziehen sich auf transcript.txt (0-basiert, Ende exklusiv).

- [F0001] 0–359: “Sie arbeiten als Vertretung des Hausarztes in der Praxis von Doktor Berg. Der Patient Jonas Neu stellt sich heute mit Symptomen eines gripalen Infekts bei Ihnen vor. Vor der körperlichen Untersuchung möchten Sie mit ihm ein Gespräch über seine aktuellen Beschwerden führen. Hallo, was führt Sie her? Ich bin seit drei Monaten erkältet mitten im Sommer, und”
- [F0001] 359–718: “zwar heftig mein Kopf tut dauernd weh meine Nasennebenhöhlen sind eigentlich ständig zu ab und zu, denke ich, dass ich Fieber habe und das nervt ohne Ende. Ich habe da auch keine Zeit zu kurz gesagt, das muss aufhören und deswegen bin ich hier seit drei Monaten in Fekt. Ja das nervt, das nervt Sie haben weder Lust noch Zeit dazu, haben Sie gesagt. Womit”
- [F0002] 1431–1789: “war und deswegen musste den ganzen Tag die Klimaanlage voll laufen und alle anderen haben gefroren mitunter ich und nur mit einem T Shirt an und eigentlich ging es da los. Ja also klassisch erkältet. Was ich spüre ist, dass da schon relativ viel Druck ist bei Ihnen. Ja was heißt Druck, ich habe halt, ich bin halt gerade an einem Projekt, das geht nur in”
- [F0003] 359–718: “zwar heftig mein Kopf tut dauernd weh meine Nasennebenhöhlen sind eigentlich ständig zu ab und zu, denke ich, dass ich Fieber habe und das nervt ohne Ende. Ich habe da auch keine Zeit zu kurz gesagt, das muss aufhören und deswegen bin ich hier seit drei Monaten in Fekt. Ja das nervt, das nervt Sie haben weder Lust noch Zeit dazu, haben Sie gesagt. Womit”
- [F0004] 1074–1431: “was heißt ausgebremst? Ich funktioniere schon, aber unter Schmerzen sozusagen, also ich nehme ab und zu ein bisschen Iboprofen um das zu lindern, aber ich versuche halt nicht zu übertreiben, weil ich weiß, dass ja auch belastet den Körper. Haben Sie die Idee, wie es dazu kam? Ja ich habe in der Besprechung gesessen den ganzen Tag, wo zwei Leuten zu heiß”
- [F0004] 2853–3204: “und so. Also für Pause ist gerade nicht so wirklich Platz, also ich habe die Hoffnung, sie würden mir halt was geben, was irgendwie aufräumten Antibiotikum oder wenigstens was die Symptome lindert. Ibuprofen hilft einigermaßen, aber wie gesagt, ich will das halt auch nicht da entnehmen. Ja, also ich möchte Sie natürlich gleich auf jeden Fall noch”
- [F0005] 1074–1431: “was heißt ausgebremst? Ich funktioniere schon, aber unter Schmerzen sozusagen, also ich nehme ab und zu ein bisschen Iboprofen um das zu lindern, aber ich versuche halt nicht zu übertreiben, weil ich weiß, dass ja auch belastet den Körper. Haben Sie die Idee, wie es dazu kam? Ja ich habe in der Besprechung gesessen den ganzen Tag, wo zwei Leuten zu heiß”
- [F0006] 1789–2145: “sechs Monat, man hatte geht das, wir sind jetzt gut halb durch und erzählt halt jeder Tag, ne da machen wir auch Überstunden und das muss halt laufen, das ist die Zeit des E knapp bemessen und das muss halt durchgezogen werden einfach eine Projekt, wo arbeiten die in der Forschung an der freien Uni Berlin. Da ist viel Druck. Der Vertrag dauert so lange”
- [F0007] 1789–2145: “sechs Monat, man hatte geht das, wir sind jetzt gut halb durch und erzählt halt jeder Tag, ne da machen wir auch Überstunden und das muss halt laufen, das ist die Zeit des E knapp bemessen und das muss halt durchgezogen werden einfach eine Projekt, wo arbeiten die in der Forschung an der freien Uni Berlin. Da ist viel Druck. Der Vertrag dauert so lange”
- [F0008] 2145–2497: “wie das Projekt und danach kommt dann hoffentlich der nächste. Von daher ja also es geht quasi von halbem Jahr zu halben Jahr immer. Also sie haben die klassischen Symptome einer typischen Präpareninfektion beschrieben mit Nasennebenhöhlen beschwerden, halschmerzen, Kopf, Schmerzen abgeschlagenheit, die sich jetzt lange hinziehen und auch ziemlich”
- [F0009] 2145–2497: “wie das Projekt und danach kommt dann hoffentlich der nächste. Von daher ja also es geht quasi von halbem Jahr zu halben Jahr immer. Also sie haben die klassischen Symptome einer typischen Präpareninfektion beschrieben mit Nasennebenhöhlen beschwerden, halschmerzen, Kopf, Schmerzen abgeschlagenheit, die sich jetzt lange hinziehen und auch ziemlich”
- [F0010] 2497–2853: “typisch begonnen haben, was ich jetzt nicht gehört habe, ist, dass Sie zwischendrin mal irgendwie eine Pause gemacht haben. Sie sprechen von Ebo Prophäen und anderen Hilfsmitteln, aber Pause wann also ich arbeite jetzt nicht jedes Wochenende durch oder so, aber unsere Arbeitstage dauernd zehn elf Stunden manchmal auch noch mit Unterlagen danach sichten”
- [F0011] 2497–2853: “typisch begonnen haben, was ich jetzt nicht gehört habe, ist, dass Sie zwischendrin mal irgendwie eine Pause gemacht haben. Sie sprechen von Ebo Prophäen und anderen Hilfsmitteln, aber Pause wann also ich arbeite jetzt nicht jedes Wochenende durch oder so, aber unsere Arbeitstage dauernd zehn elf Stunden manchmal auch noch mit Unterlagen danach sichten”
- [F0011] 2853–3204: “und so. Also für Pause ist gerade nicht so wirklich Platz, also ich habe die Hoffnung, sie würden mir halt was geben, was irgendwie aufräumten Antibiotikum oder wenigstens was die Symptome lindert. Ibuprofen hilft einigermaßen, aber wie gesagt, ich will das halt auch nicht da entnehmen. Ja, also ich möchte Sie natürlich gleich auf jeden Fall noch”
- [F0012] 2853–3204: “und so. Also für Pause ist gerade nicht so wirklich Platz, also ich habe die Hoffnung, sie würden mir halt was geben, was irgendwie aufräumten Antibiotikum oder wenigstens was die Symptome lindert. Ibuprofen hilft einigermaßen, aber wie gesagt, ich will das halt auch nicht da entnehmen. Ja, also ich möchte Sie natürlich gleich auf jeden Fall noch”
- [F0013] 2853–3204: “und so. Also für Pause ist gerade nicht so wirklich Platz, also ich habe die Hoffnung, sie würden mir halt was geben, was irgendwie aufräumten Antibiotikum oder wenigstens was die Symptome lindert. Ibuprofen hilft einigermaßen, aber wie gesagt, ich will das halt auch nicht da entnehmen. Ja, also ich möchte Sie natürlich gleich auf jeden Fall noch”
- [F0014] 4271–4627: “gehört über diesen Infekte einiges erfahren. Das tun Sie sonst so, wie leben Sie sonst so? Meine Freundin wohnt hier, das heißt Wochenendes ab und zu dann hierher fahren es natürlich auch ein bisschen eng für zwei Tage dann. Ich glaube es auch jetzt nicht dauernd, aber zu viel anderen komme ich gerade nicht, also Hobby Solar Sport so ist jetzt gerade”
- [F0015] 4271–4627: “gehört über diesen Infekte einiges erfahren. Das tun Sie sonst so, wie leben Sie sonst so? Meine Freundin wohnt hier, das heißt Wochenendes ab und zu dann hierher fahren es natürlich auch ein bisschen eng für zwei Tage dann. Ich glaube es auch jetzt nicht dauernd, aber zu viel anderen komme ich gerade nicht, also Hobby Solar Sport so ist jetzt gerade”
- [F0016] 4627–4983: “nicht die Gelegenheit und auch nicht die Energie für vorhanden brauchen Sie nehmen wir an, das Einzige, was ich Ihnen wirklich guten Gewissensempfehlen könnte wäre, sie krank zu schreiben für zwei, drei Tage um sich zu schonen ganz ungünstig. Also das einzige meinen Sie. Ja man kann natürlich symptomatisch viel tun, wie sie es ja auch schon machen mit”
- [F0017] 3204–3557: “untersuchen. Aber wenn ich das finde, was ich erwarte, dann haben Sie ein jetzt sehr lange sich hinziehenden viralen Infekt, wo außer Ruhe und Schonung eigentlich kein Kraut gegen Gewachsen ist. Die Antibiotika schaden mehr als dass sie nützen, weil die natürlich nur gegen bakterielle Infekte helfen. Und das eigentliche, worum es geht, nämlich dem”
- [F0018] 3204–3557: “untersuchen. Aber wenn ich das finde, was ich erwarte, dann haben Sie ein jetzt sehr lange sich hinziehenden viralen Infekt, wo außer Ruhe und Schonung eigentlich kein Kraut gegen Gewachsen ist. Die Antibiotika schaden mehr als dass sie nützen, weil die natürlich nur gegen bakterielle Infekte helfen. Und das eigentliche, worum es geht, nämlich dem”
- [F0019] 3204–3557: “untersuchen. Aber wenn ich das finde, was ich erwarte, dann haben Sie ein jetzt sehr lange sich hinziehenden viralen Infekt, wo außer Ruhe und Schonung eigentlich kein Kraut gegen Gewachsen ist. Die Antibiotika schaden mehr als dass sie nützen, weil die natürlich nur gegen bakterielle Infekte helfen. Und das eigentliche, worum es geht, nämlich dem”
- [F0019] 4983–5342: “Ibopoffee, das beseitigt halt die Symptome und der Körper kriegt halt, dass das er braucht, nämlich Ruhe nicht. Tja und das ist das ist schon was, was ich spür an kann, dass sie sehr, dass da sehr viel Spannung ist und einfach Druck und ich sehe das oft, dass dann irgendwann einfach zu viel ist natürlich auch schwierig verstehe, was Sie sagen, aber es ist”
- [F0020] 4627–4983: “nicht die Gelegenheit und auch nicht die Energie für vorhanden brauchen Sie nehmen wir an, das Einzige, was ich Ihnen wirklich guten Gewissensempfehlen könnte wäre, sie krank zu schreiben für zwei, drei Tage um sich zu schonen ganz ungünstig. Also das einzige meinen Sie. Ja man kann natürlich symptomatisch viel tun, wie sie es ja auch schon machen mit”
- [F0021] 3557–3916: “Körper Ruhe zu verschaffen, wird natürlich durch die Tablette sowieso nicht gelöst. Ja, aber das Meter Ruhe klappt halt im Moment nicht, was würde passieren? Naja, erstmal ist das Zeit, die dann einfach fehlt, wie gesagt hier ist eh sehr knapp gemessen. Zweitens, ich will meinen nächsten Vertrag kriegen und ehrlich gesagt, ich habe auch schon lange nicht”
- [F0021] 3916–4271: “mehr gehört, dass man sich wegen Erkältung krank schreiben lässt, dass er scheint mir doch ein bisschen übertrieben einfach. Ja also ich habe ja nicht irgendwie die Masern oder so und ich habe eine Erkältung die anderen in ihrem Job, den scheint gerade nix zu fehlen. Wie sieht es denn sonst in ihrem Leben aus? Also ich habe jetzt viel über die Arbeit”
- [F0021] 5342–5699: “irgendwie das einzige, was ich mir im Prinzip nicht leisten kann. Deswegen bin ich jetzt ein bisschen in einer Zwickmühle da. Ja, das ist ein Dilemma, ne. Also ihn leuchtet aber schon ein, was ich ihnen empfehle theoretisch ja, was würden Sie Ihrem besten Freund empfehlen bei bei anderen Leuten ist es immer anders, ne, ja ich gebe zu, ich würde sagen,”
- [F0022] 3916–4271: “mehr gehört, dass man sich wegen Erkältung krank schreiben lässt, dass er scheint mir doch ein bisschen übertrieben einfach. Ja also ich habe ja nicht irgendwie die Masern oder so und ich habe eine Erkältung die anderen in ihrem Job, den scheint gerade nix zu fehlen. Wie sieht es denn sonst in ihrem Leben aus? Also ich habe jetzt viel über die Arbeit”
- [F0023] 3916–4271: “mehr gehört, dass man sich wegen Erkältung krank schreiben lässt, dass er scheint mir doch ein bisschen übertrieben einfach. Ja also ich habe ja nicht irgendwie die Masern oder so und ich habe eine Erkältung die anderen in ihrem Job, den scheint gerade nix zu fehlen. Wie sieht es denn sonst in ihrem Leben aus? Also ich habe jetzt viel über die Arbeit”
- [F0024] 4983–5342: “Ibopoffee, das beseitigt halt die Symptome und der Körper kriegt halt, dass das er braucht, nämlich Ruhe nicht. Tja und das ist das ist schon was, was ich spür an kann, dass sie sehr, dass da sehr viel Spannung ist und einfach Druck und ich sehe das oft, dass dann irgendwann einfach zu viel ist natürlich auch schwierig verstehe, was Sie sagen, aber es ist”
- [F0024] 5699–6053: “dass ich krank schreiben auch mit dem Quatsch, wenn ihre Freundin versuche das nicht so sehr zu thematisieren, ehrlich gesagt, aber deckt jetzt auch nicht den Eindruck, als ob sie das total gut findet, wie es mir geht. Tja, jetzt spüre ich außer diesem gewissen Druck, den ich ja schon erwähnt habe, auch noch eine gewisse Hilflosigkeit. Ja, was könnten”
- [F0025] 6410–6766: “dass es vor allen Dingen mit diesem Stress zu tun hat. Und es ist für wichtig halte, dass sie sich sozusagen dieser Herausforderung stellen. Sie merken, es ist ein bisschen schwierig und wollen sich jetzt auch nicht krank schreiben lassen, höre ich raus. Aber nehmen vielleicht die Idee mit mal zu gucken, was geht die Frage wäre ja auch, wie lang muss”
- [F0026] 6766–7117: “ich krank geschrieben sein, dass das weggeht. Ja man würde mit einigen wenigen Tagen anfangen. Mit dem Wochenende hätten Sie dann ja jetzt von heute ausgerechnet fast eine Woche fünf Tage sich zu erholen und mal zu gucken, wie sie ein bisschen den Druck aus dem System nehmen, könnten mal telefonieren. Gut, dann würden wir jetzt die Anukündigkeit”
- [F0027] 6766–7117: “ich krank geschrieben sein, dass das weggeht. Ja man würde mit einigen wenigen Tagen anfangen. Mit dem Wochenende hätten Sie dann ja jetzt von heute ausgerechnet fast eine Woche fünf Tage sich zu erholen und mal zu gucken, wie sie ein bisschen den Druck aus dem System nehmen, könnten mal telefonieren. Gut, dann würden wir jetzt die Anukündigkeit”
- [F0028] 3204–3557: “untersuchen. Aber wenn ich das finde, was ich erwarte, dann haben Sie ein jetzt sehr lange sich hinziehenden viralen Infekt, wo außer Ruhe und Schonung eigentlich kein Kraut gegen Gewachsen ist. Die Antibiotika schaden mehr als dass sie nützen, weil die natürlich nur gegen bakterielle Infekte helfen. Und das eigentliche, worum es geht, nämlich dem”
- [F0028] 7117–7193: “untersuchung noch vornehmen und treffen uns dann gleich vorne an der Liege.”
- [F0029] 5342–5699: “irgendwie das einzige, was ich mir im Prinzip nicht leisten kann. Deswegen bin ich jetzt ein bisschen in einer Zwickmühle da. Ja, das ist ein Dilemma, ne. Also ihn leuchtet aber schon ein, was ich ihnen empfehle theoretisch ja, was würden Sie Ihrem besten Freund empfehlen bei bei anderen Leuten ist es immer anders, ne, ja ich gebe zu, ich würde sagen,”
- [F0030] 5699–6053: “dass ich krank schreiben auch mit dem Quatsch, wenn ihre Freundin versuche das nicht so sehr zu thematisieren, ehrlich gesagt, aber deckt jetzt auch nicht den Eindruck, als ob sie das total gut findet, wie es mir geht. Tja, jetzt spüre ich außer diesem gewissen Druck, den ich ja schon erwähnt habe, auch noch eine gewisse Hilflosigkeit. Ja, was könnten”
- [F0031] 5699–6053: “dass ich krank schreiben auch mit dem Quatsch, wenn ihre Freundin versuche das nicht so sehr zu thematisieren, ehrlich gesagt, aber deckt jetzt auch nicht den Eindruck, als ob sie das total gut findet, wie es mir geht. Tja, jetzt spüre ich außer diesem gewissen Druck, den ich ja schon erwähnt habe, auch noch eine gewisse Hilflosigkeit. Ja, was könnten”
- [F0032] 5699–6053: “dass ich krank schreiben auch mit dem Quatsch, wenn ihre Freundin versuche das nicht so sehr zu thematisieren, ehrlich gesagt, aber deckt jetzt auch nicht den Eindruck, als ob sie das total gut findet, wie es mir geht. Tja, jetzt spüre ich außer diesem gewissen Druck, den ich ja schon erwähnt habe, auch noch eine gewisse Hilflosigkeit. Ja, was könnten”
- [F0033] 6410–6766: “dass es vor allen Dingen mit diesem Stress zu tun hat. Und es ist für wichtig halte, dass sie sich sozusagen dieser Herausforderung stellen. Sie merken, es ist ein bisschen schwierig und wollen sich jetzt auch nicht krank schreiben lassen, höre ich raus. Aber nehmen vielleicht die Idee mit mal zu gucken, was geht die Frage wäre ja auch, wie lang muss”
